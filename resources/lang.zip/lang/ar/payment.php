<?php

return [
    'title'             => 'دفع',
    'create_payment'    => 'إنشاء الدفع',
    'taken_by'          => 'اخذت بواسطة',
    'payment_type'      => 'نوع الدفع',
    'payment_info'      => 'معلومات الدفع',
    'paid_to'           => 'دفع الثمن ل',
    'form' => [
        'payment_amount' => 'مبلغ الدفع',
        'payment_type' => 'نوع الدفع',
        'payment_description' => 'وصف الدفع',
    ]
];