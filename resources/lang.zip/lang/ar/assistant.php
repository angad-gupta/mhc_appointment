<?php

return [
    'assistant' => 'مساعد',
    'create_assistant' => 'مساعد جديد',
    'all_assistant' => 'كل مساعد',
    'edit_assistant' => 'تحرير المساعد'
];