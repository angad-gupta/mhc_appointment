<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 6:54 PM
 */

return [
    'doctor'        =>  'طبيب',
    'create_doctor' =>  'اصنع دكتور',
    'edit_doctor'   =>  'تحرير الطبيب',
    'delete_doctor' =>  'حذف الطبيب',
    'all_doctor'    =>  'كل دكتور',
    'doctor_photo'  =>  'صور الطبيب',
    'title'         =>  'عنوان',
    'full_name'     =>  'الاسم الكامل',
    'phone'         =>  'هاتف',
    'sex'           =>  'جنس',
    'info'          =>  'معلومات',
    'description'   =>  'وصف',
    'select_doctor' =>  'اختر الطبيب',
    'feature_message'   =>  'متميز ! سوف تظهر في الصفحة الرئيسية'

];