<?php
/**
 * Created by PhpStorm.
 * User: rifat
 * Date: 3/26/19
 * Time: 6:39 PM
 */

return [
    'prescription_helper'   =>  'مساعد الوصفة',
    'create'                =>  'إنشاء المساعد',
    'edit'                  =>  'تحرير الوصفة المساعد',
    'all'                   =>  'جميع المساعدين',
    'helper_text'           =>  'النص المساعد',
    'category'              =>  'الفئة'
];