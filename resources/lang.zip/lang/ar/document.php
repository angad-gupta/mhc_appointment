<?php

return [
    'document'    =>  'وثيقة',
    'create_document'   =>  'إنشاء وثيقة',
    'patient_document'  =>  'وثيقة المريض'
];