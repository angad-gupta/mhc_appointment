<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 5:55 PM
 */

return [
    'drug' => 'المخدرات',
    'create_drug' => 'خلق المخدرات',
    'all_drug' => 'جميع المخدرات',
    'edit_drug' => 'تحرير المخدرات',
    'delete_drug' => 'حذف المخدرات',
    'trade_name' => 'اسم تجاري',
    'generic_name' => 'اسم عام',
    'drug_image' => 'صورة المخدرات',
    'note' => 'ملحوظة',
    'success' => 'نجاح',
    'save_message' => 'تم حفظ المخدرات بنجاح',
    'update_message' => 'تم تحديث الدواء بنجاح',
    'delete_message' => 'تم حذف المخدرات بنجاح',
    'report' => 'أبلغ عن',
    'select_drug' => 'حدد المخدرات'
];