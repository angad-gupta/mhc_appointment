<?php

return [
    'mailbox'       => 'صندوق بريد',
    'empty'         => 'صندوق البريد فارغ',
    'reply_mail'    => 'الرد البريد',
    'replies'       => 'ردود',
    'no_reply'      => 'لا يوجد رد',
    'send_mail'     => 'ارسل بريد',
    'form'  =>  [
        'to'        =>  'إلى :',
        'subject'   =>  'موضوع',
        'message'   =>  'رسالة'
    ]
];