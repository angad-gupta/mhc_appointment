<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 6:24 PM
 */

return [
    'schedule'          =>  'جدول',
    'my_schedule'       =>  'جدولي',
    'create_schedule'   =>  'إنشاء جدول',
    'day'               =>  'يوم',
    'date'              =>  'تاريخ',
    'time'              =>  'زمن',
    'start_time'        =>  'وقت البدء',
    'end_time'          =>  'وقت النهاية',
    'total_schedule'    =>  'الجدول الكلي'
];