<?php

return [
    'prescription_setting' => 'إعداد الوصفة',
    'create' => 'إنشاء إعداد وصفة طبية',
    'all' => 'جميع الوصفات الطبية',
    'form' => [
        'show_top_left' => 'عرض أعلى اليسار',
        'top_left_text' => 'النص الأيسر العلوي',
        'show_top_right' => 'إظهار أعلى اليمين',
        'top_right_text' => 'النص العلوي الأيمن'
    ]
];