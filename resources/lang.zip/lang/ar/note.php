<?php

return [
    'note' => 'ملحوظة',
    'patient_note' => 'ملاحظة المريض',
    'create_note' => 'إنشاء ملاحظة'
];