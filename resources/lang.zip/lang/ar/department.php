<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/8/18
 * Time: 8:32 PM
 */

return [
    'department'        =>  'قسم، أقسام',
    'create_department' =>  'إنشاء قسم',
    'edit_department'   =>  'تحرير القسم',
    'delete_department' =>  'حذف القسم',
    'all_department'    =>  'كل قسم',
    'success_message'   =>  'تمت إضافة القسم بنجاح',
    'update_message'    =>  'تم تحديث القسم بنجاح',
    'delete_message'    =>  'تم حذف القسم بنجاح',
    'title'             =>  'عنوان'
];