<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 1:45 PM
 */

return [
    'admin'         =>  'مشرف',
    'admin_users'   =>  'المستخدمين المشرف',
    'admin_photo'   =>  'صورة فوتوغرافية',
    'create_admin'  =>  'المسؤول',
    'edit_admin'    =>  'تحرير المسؤول',
    'delete_admin'  =>  'حذف المسؤول',
    'all_admin'     =>  'كل الادارية',
    'show_admin'    =>  ':attribute تفاصيل',
    'full_name'     =>  'الاسم الكامل',
];