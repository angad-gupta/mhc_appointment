<?php

return [
    'mailbox'       => 'मेलबॉक्स',
    'empty'         => 'खाली पेटी',
    'reply_mail'    => 'मेल का जवाब दें',
    'replies'       => 'जवाब',
    'no_reply'      => 'कोई उत्तर नहीं है',
    'send_mail'     => 'मेल भेजे',
    'form'  =>  [
        'to'        =>  'To :',
        'subject'   =>  'विषय',
        'message'   =>  'संदेश'
    ]
];