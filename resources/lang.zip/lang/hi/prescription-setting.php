<?php

return [
    'prescription_setting' => 'प्रिस्क्रिप्शन सेटिंग',
    'create' => 'प्रिस्क्रिप्शन सेटिंग बनाएँ',
    'all' => 'सभी प्रिस्क्रिप्शन सेटिंग',
    'form' => [
        'show_top_left' => 'शीर्ष बाएँ दिखाएँ',
        'top_left_text' => 'टॉप लेफ्ट टेक्स्ट',
        'show_top_right' => 'टॉप राइट दिखाओ',
        'top_right_text' => 'शीर्ष सही पाठ'
    ]
];