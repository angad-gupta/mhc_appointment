<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/8/18
 * Time: 8:32 PM
 */

return [
    'department'        =>  'विभाग',
    'create_department' =>  'विभाग बनाएँ',
    'edit_department'   =>  'विभाग संपादित करें',
    'delete_department' =>  'विभाग हटाएं',
    'all_department'    =>  'सभी विभाग',
    'success_message'   =>  'विभाग को सफलतापूर्वक जोड़ा गया है',
    'update_message'    =>  'विभाग को सफलतापूर्वक अपडेट कर दिया गया है',
    'delete_message'    =>  'विभाग को सफलतापूर्वक हटा दिया गया है',
    'title'             =>  'शीर्षक'
];