<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 1:45 PM
 */

return [
    'admin'         =>  'व्यवस्थापक',
    'admin_users'   =>  'व्यवस्थापक उपयोगकर्ता',
    'admin_photo'   =>  'एडमिन फोटो',
    'create_admin'  =>  'व्यवस्थापक बनाएँ',
    'edit_admin'    =>  'व्यवस्थापक संपादित करें',
    'delete_admin'  =>  'व्यवस्थापक हटाएं',
    'all_admin'     =>  'सभी व्यवस्थापक',
    'show_admin'    =>  ':attribute विवरण',
    'full_name'     =>  'पूरा नाम',
];