<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 5:55 PM
 */

return [
    'drug' => 'दवा',
    'create_drug' => 'दवा बनाएँ',
    'all_drug' => 'सभी दवा',
    'edit_drug' => 'दवा संपादित करें',
    'delete_drug' => 'दवा को हटा दें',
    'trade_name' => 'व्यापारिक नाम',
    'generic_name' => 'सामान्य नाम',
    'drug_image' => 'ड्रग इमेज',
    'note' => 'ध्यान दें',
    'success' => 'सफलता',
    'save_message' => 'दवा को सफलतापूर्वक बचाया गया है',
    'update_message' => 'ड्रग को सफलतापूर्वक अपडेट किया गया है',
    'delete_message' => 'ड्रग को सफलतापूर्वक हटा दिया गया है',
    'report' => 'रिपोर्ट',
    'select_drug'   =>  'दवा का चयन करें'
];