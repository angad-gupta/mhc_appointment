<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 6:24 PM
 */

return [
    'schedule'          =>  'अनुसूची',
    'my_schedule'       =>  'मेरे अनुसूची',
    'create_schedule'   =>  'शेड्यूल बनाएं',
    'day'               =>  'दिन',
    'date'              =>  'दिनांक',
    'time'              =>  'पहर',
    'start_time'        =>  'समय शुरू',
    'end_time'          =>  'अंतिम समय',
    'total_schedule'    =>  'कुल अनुसूची'
];