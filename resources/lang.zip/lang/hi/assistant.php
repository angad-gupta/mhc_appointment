<?php

return [
    'assistant' => 'सहायक',
    'create_assistant' => 'नया सहायक',
    'all_assistant' => 'सभी सहायक',
    'edit_assistant' => 'सहायक संपादित करें'
];