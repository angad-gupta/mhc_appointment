<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 6:54 PM
 */

return [
    'doctor'        =>  'चिकित्सक',
    'create_doctor' =>  'चिकित्सक बनाएँ',
    'edit_doctor'   =>  'चिकित्सक को संपादित करें',
    'delete_doctor' =>  'चिकित्सक को हटाओ',
    'all_doctor'    =>  'सभी चिकित्सक',
    'doctor_photo'  =>  'चिकित्सक फोटो',
    'title'         =>  'शीर्षक',
    'full_name'     =>  'पूरा नाम',
    'phone'         =>  'फ़ोन',
    'sex'           =>  'लिंग',
    'info'          =>  'जानकारी',
    'description'   =>  'विवरण',
    'select_doctor' =>  'चिकित्सक का चयन करें',
    'feature_message'   =>  'फीचर्ड! मुख्य पृष्ठ में दिखाएगा'

];