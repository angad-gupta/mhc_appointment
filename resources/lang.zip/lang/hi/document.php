<?php

return [
    'document'    =>  'दस्तावेज़',
    'create_document'   =>  'दस्तावेज़ बनाएँ',
    'patient_document'  =>  'रोगी दस्तावेज़'
];