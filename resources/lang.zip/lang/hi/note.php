<?php

return [
    'note' => 'ध्यान दें',
    'patient_note' => 'रोगी का नोट',
    'create_note' => 'नोट बनाएँ'
];