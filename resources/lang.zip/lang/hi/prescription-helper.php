<?php
/**
 * Created by PhpStorm.
 * User: rifat
 * Date: 3/26/19
 * Time: 6:39 PM
 */

return [
    'prescription_helper'   =>  'प्रिस्क्रिप्शन हेल्पर',
    'create'                =>  'हेल्पर बनाएं',
    'edit'                  =>  'प्रिस्क्रिप्शन हेल्पर संपादित करें',
    'all'                   =>  'सभी सहायकों',
    'helper_text'           =>  'सहायक पाठ',
    'category'              =>  'वर्ग'
];