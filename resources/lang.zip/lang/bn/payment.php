<?php

return [
    'title'             => 'পারিশ্রমিক',
    'create_payment'    => 'পারিশ্রমিক আদায় করুন',
    'taken_by'          => 'দ্বারা গৃহীত',
    'payment_type'      => 'পারিশ্রমিকের ধরন',
    'payment_info'      => 'পারিশ্রমিকের তথ্য',
    'paid_to'           => 'গ্রহনকারী',
    'form' => [
        'payment_amount'        => 'পারিশ্রমিকের পরিমান',
        'payment_type'          => 'পারিশ্রমিক প্রদানের ধরন',
        'payment_description'   => 'পারিশ্রমিক ডেসক্রিপশন',
    ]
];