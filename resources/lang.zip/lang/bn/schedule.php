<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 6:24 PM
 */

return [
    'schedule'          =>  'সময়তালিকা',
    'my_schedule'       =>  'আমার সময়তালিকা',
    'create_schedule'   =>  'সময়তালিকা তৈরী করুন',
    'day'               =>  'দিন',
    'date'              =>  'তারিখ',
    'time'              =>  'সময়',
    'start_time'        =>  'শুরুর সময়',
    'end_time'          =>  'শেষের সময়',
    'total_schedule'    =>  'মোট সময়সূচী'
];