<?php

return [
    'assistant' => 'সাহায্যকারী',
    'create_assistant' => 'নতুন সাহায্যকারী',
    'all_assistant' => 'সকল সাহায্যকারী',
    'edit_assistant' => 'সাহায্যকারী সম্পাদন করুন'
];