<?php

return [
    'your_next_followup_date' => 'আপনি পরবর্তী তারিখ অনুসরণ করুন :',
    'invoice' => [
        'title' =>  'চালান',
        'invoice_id'    =>  'চালান আইডি',
        'consultancy_fees'  =>  'পরামর্শ ফি',
        'total' =>  'মোট',
        'only'  =>  'মাত্র'
    ]
];