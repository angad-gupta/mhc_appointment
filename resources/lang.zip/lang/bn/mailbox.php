<?php

return [
    'mailbox'       => 'মেইলবক্স',
    'empty'         => 'মেইলবক্স খালি',
    'reply_mail'    => 'মেইলের রিপ্লাই দিন',
    'replies'       => 'রিপ্লাই সমুহ',
    'no_reply'      => 'কোন রিপ্লাই নেই',
    'send_mail'     => 'মেইল পাঠান',
    'form'  =>  [
        'to'        =>  'টু :',
        'subject'   =>  'বিষয়',
        'message'   =>  'মেসেজ'
    ]
];