<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 5:55 PM
 */

return [
    'drug' => 'ঔষধ',
    'create_drug' => 'নতুন ঔষধ',
    'all_drug' => 'সকল ঔষধ',
    'edit_drug' => 'ঔষধ সম্পাদন করুন',
    'delete_drug' => 'ঔষধ মুছে ফেলুন',
    'trade_name' => 'বাণিজ্যিক নাম',
    'generic_name' => 'জেনেরিক নাম',
    'drug_image' => 'ঔষধের ছবি',
    'note' => 'নোট',
    'success' => 'সফল',
    'save_message' => 'ঔষধ সফলভাবে সংরক্ষিত হয়েছে',
    'update_message' => 'ঔষধ সফলভাবে সম্পাদন করা হয়েছে',
    'delete_message' => 'ঔষধ সফলভাবে মুছে ফেলা হয়েছে',
    'report' => 'প্রতিবেদন',
    'select_drug'   =>  'ঔষধ নির্বাচন করুন'
];