<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/8/18
 * Time: 8:32 PM
 */

return [
    'department'        =>  'বিভাগ',
    'create_department' =>  'বিভাগ তৈরি করুন',
    'edit_department'   =>  'বিভাগ সম্পাদনা করুন',
    'delete_department' =>  'বিভাগ মুছে দিন',
    'all_department'    =>  'সব বিভাগ',
    'success_message'   =>  'বিভাগ সফলভাবে যোগ করা হয়েছে',
    'update_message'    =>  'বিভাগ সফলভাবে আপডেট করা হয়েছে',
    'delete_message'    =>  'বিভাগ সফলভাবে মুছে ফেলা হয়েছে',
    'title'             =>  'বিভাগের নাম'
];