<?php

return [
    'prescription_setting' => 'প্রেসক্রিপশন সেটিং',
    'create' => 'প্রেসক্রিপশন সেটিং তৈরি করুন',
    'all' => 'সমস্ত প্রেসক্রিপশন সেটিং',
    'form' => [
        'show_top_left' => 'উপরে বামে দেখান',
        'top_left_text' => 'উরপরে বামের লিখা',
        'show_top_right' => 'উপরে ডানে দেখান',
        'top_right_text' => 'উরপরে ডানে লিখা'
    ]
];