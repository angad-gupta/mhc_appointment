<?php

return [
    'note' => 'নোট',
    'patient_note' => 'রোগীর নোট',
    'create_note' => 'নোট তৈরী করুন'
];