<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 1:45 PM
 */

return [
    'admin' => 'প্রশাসনিক',
    'admin_users' => 'প্রশাসনিক ব্যাবহারকারী',
    'admin_photo' => 'ছবি',
    'create_admin' => 'প্রশাসনিক ব্যাবহারকারী তৈরী করুন',
    'edit_admin' => 'প্রশাসনিক ব্যাবহারকারী সম্পাদন করুন',
    'delete_admin' => 'প্রশাসনিক ব্যাবহারকারী মুছে ফেলুন',
    'all_admin' => 'সকল প্রশাসনিক ব্যাবহারকারী',
    'show_admin' => ':attribute details',
    'full_name' => 'পুরো নাম',

];