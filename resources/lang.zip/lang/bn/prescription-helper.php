<?php
/**
 * Created by PhpStorm.
 * User: rifat
 * Date: 3/26/19
 * Time: 6:39 PM
 */

return [
    'prescription_helper'   =>  'ব্যবস্থাপত্রের সাহায্যকারী',
    'create'                =>  'সাহায্যকারী তৈরী করুন',
    'edit'                  =>  'সাহায্যকারী সম্পাদন করুন',
    'all'                   =>  'সকল সাহায্যকারী',
    'helper_text'           =>  'সাহায্যকারী টেক্স',
    'category'              =>  'বিভাগ'
];