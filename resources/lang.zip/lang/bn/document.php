<?php

return [
    'document' => 'কাগজপত্র',
    'create_document' => 'কাগজপত্র যুক্ত করুন',
    'patient_document' => 'রোগীর কাগজপত্র'
];