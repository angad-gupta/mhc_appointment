<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 6:54 PM
 */

return [
    'doctor'        =>  'ডাক্তার',
    'create_doctor' =>  'ডাক্তার যুক্ত করুন',
    'edit_doctor'   =>  'ডাক্তার সম্পাদনা করুন',
    'delete_doctor' =>  'ডাক্তার মুছে দিন',
    'all_doctor'    =>  'সকল ডাক্তার',
    'doctor_photo'  =>  'ডাক্তারের ছবি',
    'title'         =>  'খেতাব',
    'full_name'     =>  'পুরো নাম',
    'phone'         =>  'ফোন',
    'sex'           =>  'লিঙ্গ',
    'info'          =>  'তথ্য',
    'description'   =>  'বিবরণ',
    'select_doctor' =>  'ডাক্তার নির্বাচন করুন',
    'feature_message'   =>  'বৈশিষ্ট্যযুক্ত ! প্রধান পাতায় প্রদর্শন করা হবে'

];