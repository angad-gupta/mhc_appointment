<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 1:45 PM
 */

return [
    'admin'         =>  'Admin',
    'admin_users'   =>  'Admin Users',
    'admin_photo'   =>  'Photo',
    'create_admin'  =>  'Create Admin',
    'edit_admin'    =>  'Edit Admin',
    'delete_admin'  =>  'Delete Admin',
    'all_admin'     =>  'All Admin',
    'show_admin'    =>  ':attribute details',
    'full_name'     =>  'Full Name',
];