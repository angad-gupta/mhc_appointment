<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/8/18
 * Time: 8:32 PM
 */

return [
    'department'        =>  'Department',
    'create_department' =>  'Create Department',
    'edit_department'   =>  'Edit Department',
    'delete_department' =>  'Delete Department',
    'all_department'    =>  'All Department',
    'success_message'   =>  'Department has been added successfully',
    'update_message'    =>  'Department has been updated successfully',
    'delete_message'    =>  'Department has been deleted successfully',
    'title'             =>  'Title'
];