<?php

return [
    'assistant' => 'Assistant',
    'create_assistant' => 'New Assistant',
    'all_assistant' => 'All Assistant',
    'edit_assistant' => 'Edit Assistant'
];