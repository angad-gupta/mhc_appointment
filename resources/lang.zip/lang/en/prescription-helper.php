<?php
/**
 * Created by PhpStorm.
 * User: rifat
 * Date: 3/26/19
 * Time: 6:39 PM
 */

return [
    'prescription_helper'   =>  'Prescription Helper',
    'create'                =>  'Create Helper',
    'edit'                  =>  'Edit Prescription Helper',
    'all'                   =>  'All Helpers',
    'helper_text'           =>  'Helper Text',
    'category'              =>  'Category',
];