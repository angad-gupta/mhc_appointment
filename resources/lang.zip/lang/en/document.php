<?php

return [
    'document'    =>  'Document',
    'create_document'   =>  'Create Document',
    'patient_document'  =>  'Patient Document'
];