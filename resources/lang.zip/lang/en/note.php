<?php

return [
    'note' => 'Note',
    'patient_note' => 'Patient Note',
    'create_note' => 'Create Note'
];