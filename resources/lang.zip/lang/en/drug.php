<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 5:55 PM
 */

return [
    'drug' => 'Drug',
    'create_drug' => 'Create Drug',
    'all_drug' => 'All Drug',
    'edit_drug' => 'Edit Drug',
    'delete_drug' => 'Delete Drug',
    'trade_name' => 'Trade Name',
    'generic_name' => 'Generic Name',
    'drug_image' => 'Drug Image',
    'note' => 'Note',
    'success' => 'Success',
    'save_message' => 'Drug has been saved successfully',
    'update_message' => 'Drug has been updated successfully',
    'delete_message' => 'Drug has been deleted successfully',
    'report' => 'Report',
    'select_drug'   =>  'Select Drug'
];