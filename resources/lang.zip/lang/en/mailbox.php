<?php

return [
    'mailbox'       => 'Mailbox',
    'empty'         => 'Empty Mailbox',
    'reply_mail'    => 'Reply mail',
    'replies'       => 'Replies',
    'no_reply'      => 'There is no reply',
    'send_mail'     => 'Send Mail',
    'form'  =>  [
        'to'        =>  'To :',
        'subject'   =>  'Subject',
        'message'   =>  'Message'
    ]
];