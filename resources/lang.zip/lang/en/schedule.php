<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 6:24 PM
 */

return [
    'schedule'          =>  'Schedule',
    'my_schedule'       =>  'My Schedule',
    'create_schedule'   =>  'Create Schedule',
    'edit_schedule'     =>  'Edit Schedule',
    'day'               =>  'Day',
    'date'              =>  'Date',
    'time'              =>  'Time',
    'start_time'        =>  'Start Time',
    'end_time'          =>  'End Time',
    'total_schedule'    =>  'Total Schedule'
];