<?php

return [
    'your_next_followup_date' => 'You next follow up date :',
    'invoice' => [
        'title' =>  'Invoice',
        'invoice_id'    =>  'Invoice ID',
        'consultancy_fees'  =>  'Consultancy Fees',
        'total' =>  'Total',
        'only'  =>  'Only'
    ]
];