<?php

return [
    'prescription_setting' => 'Prescription Setting',
    'create' => 'Create Prescription Setting',
    'all' => 'All Prescription Setting',
    'form' => [
        'show_top_left' => 'Show Top Left',
        'top_left_text' => 'Top Left Text',
        'show_top_right' => 'Show Top Right',
        'top_right_text' => 'Top Right Text'
    ]
];