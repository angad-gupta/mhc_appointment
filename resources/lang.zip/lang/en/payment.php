<?php

return [
    'title'             => 'Payment',
    'create_payment'    => 'Create Payment',
    'taken_by'          => 'Taken By',
    'payment_type'      => 'P Type',
    'payment_info'      => 'P Info',
    'paid_to'           => 'Paid To',
    'form' => [
        'payment_amount' => 'Payment Amount',
        'payment_type' => 'Payment Type',
        'payment_description' => 'Payment Description',
    ]
];