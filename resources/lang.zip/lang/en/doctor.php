<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 6:54 PM
 */

return [
    'doctor'        =>  'Doctor',
    'create_doctor' =>  'Create Doctor',
    'edit_doctor'   =>  'Edit Doctor',
    'delete_doctor' =>  'Delete Doctor',
    'all_doctor'    =>  'All Doctor',
    'doctor_photo'  =>  'Doctor Photo',
    'title'         =>  'Title',
    'full_name'     =>  'Full Name',
    'phone'         =>  'Phone',
    'sex'           =>  'Sex',
    'info'          =>  'Info',
    'description'   =>  'Description',
    'select_doctor' =>  'Select Doctor',
    'feature_message'   =>  'Featured ! Will show in main page'

];