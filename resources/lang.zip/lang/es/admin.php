<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 1:45 PM
 */

return [
    'admin'         =>  'Administración',
    'admin_users'   =>  'Usuarios administradores',
    'admin_photo'   =>  'Foto administrativa',
    'create_admin'  =>  'Crear administrador',
    'edit_admin'    =>  'Editar administrador',
    'delete_admin'  =>  'Delete Admin',
    'all_admin'     =>  'Todos los administradores',
    'show_admin'    =>  ':attribute detalles',
    'full_name'     =>  'Nombre completo',
];