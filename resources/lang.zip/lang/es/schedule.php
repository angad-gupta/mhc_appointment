<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 6:24 PM
 */

return [
    'schedule'          =>  'Programar',
    'my_schedule'       =>  'Mi horario',
    'create_schedule'   =>  'Crear horario',
    'day'               =>  'Día',
    'date'              =>  'Fecha',
    'time'              =>  'Hora',
    'start_time'        =>  'Hora de inicio',
    'end_time'          =>  'Hora de finalización',
    'total_schedule'    =>  'Horario total'
];