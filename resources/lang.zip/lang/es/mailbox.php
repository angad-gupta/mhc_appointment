<?php

return [
    'mailbox'       => 'Buzón',
    'empty'         => 'Buzón vacío',
    'reply_mail'    => 'Responder correo',
    'replies'       => 'Respuestas',
    'no_reply'      => 'No hay respuesta',
    'send_mail'     => 'Enviar correo',
    'form'  =>  [
        'to'        =>  'A :',
        'subject'   =>  'Tema',
        'message'   =>  'Mensaje'
    ]
];