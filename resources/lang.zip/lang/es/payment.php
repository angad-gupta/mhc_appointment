<?php

return [
    'title'             => 'Pago',
    'create_payment'    => 'Crear pago',
    'taken_by'          => 'Tomada por',
    'payment_type'      => 'Tipo de pago',
    'payment_info'      => 'Información de pago',
    'paid_to'           => 'Pagado para',
    'form' => [
        'payment_amount' => 'Monto del pago',
        'payment_type' => 'Tipo de pago',
        'payment_description' => 'descripción de pago',
    ]
];