<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 5:55 PM
 */

return [
    'drug' => 'Fármaco',
    'create_drug' => 'Crear drogas',
    'all_drug' => 'Todas las drogas',
    'edit_drug' => 'Editar droga',
    'delete_drug' => 'Eliminar droga',
    'trade_name' => 'Nombre comercial',
    'generic_name' => 'Nombre generico',
    'drug_image' => 'Imagen de drogas',
    'note' => 'Nota',
    'success' => 'Éxito',
    'save_message' => 'La droga se ha guardado con éxito',
    'update_message' => 'La droga ha sido actualizada exitosamente',
    'delete_message' => 'La droga ha sido eliminada exitosamente',
    'report' => 'Informe',
    'select_drug'   =>  'Seleccione droga'
];