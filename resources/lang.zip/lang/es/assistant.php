<?php

return [
    'assistant' => 'Asistente',
    'create_assistant' => 'Asistente nuevo',
    'all_assistant' => 'Todo asistente',
    'edit_assistant' => 'Asistente de edición'
];