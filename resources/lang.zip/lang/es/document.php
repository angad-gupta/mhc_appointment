<?php

return [
    'document'    =>  'Documento',
    'create_document'   =>  'Crear documento',
    'patient_document'  =>  'Documento del paciente'
];