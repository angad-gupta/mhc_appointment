<?php

return [
    'prescription_setting' => 'Ajuste de prescripción',
    'create' => 'Crear configuración de prescripción',
    'all' => 'Todas las configuraciones de prescripción',
    'form' => [
        'show_top_left' => 'Mostrar arriba a la izquierda',
        'top_left_text' => 'Texto superior izquierdo',
        'show_top_right' => 'Mostrar arriba a la derecha',
        'top_right_text' => 'Texto superior derecho'
    ]
];