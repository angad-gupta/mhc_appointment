<?php
/**
 * Created by PhpStorm.
 * User: rifat
 * Date: 3/26/19
 * Time: 6:39 PM
 */

return [
    'prescription_helper'   =>  'Ayudante de prescripción',
    'create'                =>  'Crear ayudante',
    'edit'                  =>  'Editar ayudante de prescripción',
    'all'                   =>  'Todos los ayudantes',
    'helper_text'           =>  'Texto de ayuda',
    'category'              =>  'Categoría'
];