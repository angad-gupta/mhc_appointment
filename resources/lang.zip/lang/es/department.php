<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/8/18
 * Time: 8:32 PM
 */

return [
    'department'        =>  'Departamento',
    'create_department' =>  'Crear departamento',
    'edit_department'   =>  'Editar departamento',
    'delete_department' =>  'Eliminar departamento',
    'all_department'    =>  'Todo el departamento',
    'success_message'   =>  'El departamento ha sido agregado exitosamente',
    'update_message'    =>  'El departamento ha sido actualizado exitosamente',
    'delete_message'    =>  'El departamento ha sido eliminado exitosamente',
    'title'             =>  'Título'
];