<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 6:54 PM
 */

return [
    'doctor'        =>  'Médico',
    'create_doctor' =>  'Crear médico',
    'edit_doctor'   =>  'Editar doctor',
    'delete_doctor' =>  'Eliminar doctor',
    'all_doctor'    =>  'Todo el doctor',
    'doctor_photo'  =>  'Foto del doctor',
    'title'         =>  'Título',
    'full_name'     =>  'Nombre completo',
    'phone'         =>  'Teléfono',
    'sex'           =>  'Sexo',
    'info'          =>  'Informacion',
    'description'   =>  'Descripción',
    'select_doctor' =>  'Seleccionar doctor',
    'feature_message'   =>  'Destacado ! Se mostrará en la página principal.'

];