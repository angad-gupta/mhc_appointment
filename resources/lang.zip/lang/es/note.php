<?php

return [
    'note' => 'Nota',
    'patient_note' => 'Nota del paciente',
    'create_note' => 'Crear nota'
];