<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 5:55 PM
 */

return [
    'drug' => 'Droge',
    'create_drug' => 'Droge erstellen',
    'all_drug' => 'All Drug',
    'edit_drug' => 'Medikament bearbeiten',
    'delete_drug' => 'Medikament löschen',
    'trade_name' => 'Handelsname',
    'generic_name' => 'Gattungsbezeichnung',
    'drug_image' => 'Droge Bild',
    'note' => 'Hinweis',
    'success' => 'Erfolg',
    'save_message' => 'Das Medikament wurde erfolgreich gespeichert',
    'update_message' => 'Medikament wurde erfolgreich aktualisiert',
    'delete_message' => 'Medikament wurde erfolgreich gelöscht',
    'report' => 'Bericht',
    'select_drug'   =>  'Wählen Sie Droge'
];