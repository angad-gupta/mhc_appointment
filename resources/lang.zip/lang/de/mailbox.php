<?php

return [
    'mailbox'       => 'Briefkasten',
    'empty'         => 'Leere Mailbox',
    'reply_mail'    => 'Mail beantworten',
    'replies'       => 'Antworten',
    'no_reply'      => 'Es erfolgt keine Antwort',
    'send_mail'     => 'Mail senden',
    'form'  =>  [
        'to'        =>  'Zu:',
        'subject'   =>  'Gegenstand',
        'message'   =>  'Botschaft'
    ]
];