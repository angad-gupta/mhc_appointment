<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 1:45 PM
 */

return [
    'admin'         =>  'Administrator',
    'admin_users'   =>  'Admin-Benutzer',
    'admin_photo'   =>  'Foto',
    'create_admin'  =>  'Administrator erstellen',
    'edit_admin'    =>  'Admin bearbeiten',
    'delete_admin'  =>  'Admin löschen',
    'all_admin'     =>  'Alle Admin',
    'show_admin'    =>  ':attribute Einzelheiten',
    'full_name'     =>  'Vollständiger Name',
];