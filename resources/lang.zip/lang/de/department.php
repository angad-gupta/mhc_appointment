<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/8/18
 * Time: 8:32 PM
 */

return [
    'department'        =>  'Abteilung',
    'create_department' =>  'Abteilung erstellen',
    'edit_department'   =>  'Abteilung bearbeiten',
    'delete_department' =>  'Abteilung löschen',
    'all_department'    =>  'Alle Abteilung',
    'success_message'   =>  'Abteilung wurde erfolgreich hinzugefügt',
    'update_message'    =>  'Abteilung wurde erfolgreich aktualisiert',
    'delete_message'    =>  'Abteilung wurde erfolgreich gelöscht',
    'title'             =>  'Titel'
];