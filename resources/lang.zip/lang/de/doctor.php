<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/7/18
 * Time: 6:54 PM
 */

return [
    'doctor'        =>  'Arzt',
    'create_doctor' =>  'Arzt erstellen',
    'edit_doctor'   =>  'Arzt bearbeiten',
    'delete_doctor' =>  'Doktor löschen',
    'all_doctor'    =>  'Alles Doktor',
    'doctor_photo'  =>  'Doktor Foto',
    'title'         =>  'Titel',
    'full_name'     =>  'Vollständiger Name',
    'phone'         =>  'Telefon',
    'sex'           =>  'Sex',
    'info'          =>  'Info',
    'description'   =>  'Beschreibung',
    'select_doctor' =>  'Wählen Sie Arzt',
    'feature_message'   =>  'Empfohlen ! Wird auf der Hauptseite angezeigt'

];