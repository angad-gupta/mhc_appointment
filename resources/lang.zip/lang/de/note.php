<?php

return [
    'note' => 'Hinweis',
    'patient_note' => 'Patientenhinweis',
    'create_note' => 'Notiz erstellen'
];