<?php
/**
 * Created by PhpStorm.
 * User: rifat
 * Date: 3/26/19
 * Time: 6:39 PM
 */

return [
    'prescription_helper'   =>  'Rezept Helfer',
    'create'                =>  'Erstellen Helfer',
    'edit'                  =>  'Bearbeiten Rezept Helfer',
    'all'                   =>  'Alle Helfer',
    'helper_text'           =>  'Helfer Text',
    'category'              =>  'Kategorie'
];