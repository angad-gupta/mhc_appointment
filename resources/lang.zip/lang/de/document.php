<?php

return [
    'document'    =>  'Dokumentieren',
    'create_document'   =>  'Dokument erstellen',
    'patient_document'  =>  'Patientendokument'
];