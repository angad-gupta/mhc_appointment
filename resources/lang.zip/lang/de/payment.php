<?php

return [
    'title'             => 'Zahlung',
    'create_payment'    => 'Zahlung erstellen',
    'taken_by'          => 'Genommen von',
    'payment_type'      => 'P Art',
    'payment_info'      => 'P Info',
    'paid_to'           => 'Bezahlt um',
    'form' => [
        'payment_amount' => 'Zahlungsbetrag',
        'payment_type' => 'Zahlungsart',
        'payment_description' => 'Zahlungs-Beschreibung',
    ]
];