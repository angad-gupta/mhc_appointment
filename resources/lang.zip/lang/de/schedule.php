<?php
/**
 * Created by IntelliJ IDEA.
 * User: rifat
 * Date: 7/28/18
 * Time: 6:24 PM
 */

return [
    'schedule'          =>  'Zeitplan',
    'my_schedule'       =>  'Mein Zeitplan',
    'create_schedule'   =>  'Zeitplan erstellen',
    'day'               =>  'Tag',
    'date'              =>  'Datum',
    'time'              =>  'Zeit',
    'start_time'        =>  'Start Zeit',
    'end_time'          =>  'Ende Zeit',
    'total_schedule'    =>  'Gesamt Zeitplan'
];