<?php

return [
    'assistant' => 'Assistent',
    'create_assistant' => 'Neuer Assistent',
    'all_assistant' => 'Alle Assistenten',
    'edit_assistant' => 'Bearbeitungsassistent'
];