<?php

return [
    'prescription_setting' => 'Verschreibungspflichtige Einstellung',
    'create' => 'Verschreibungseinstellung erstellen',
    'all' => 'Alle Verschreibungseinstellungen',
    'form' => [
        'show_top_left' => 'Zeige Oben Links',
        'top_left_text' => 'Oben Links Text',
        'show_top_right' => 'Zeige Oben Recht',
        'top_right_text' => 'Oben Recht Text'
    ]
];